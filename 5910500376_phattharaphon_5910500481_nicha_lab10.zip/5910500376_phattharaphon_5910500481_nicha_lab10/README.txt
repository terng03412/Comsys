

The Reason Why We Seat Late
	Yesterday, I have already sent it, but We didn't see the teacher want program that  have 4 threads. We did it in 6 threads, so we fixed it in next day that made we late. 

