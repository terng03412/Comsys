#ifndef __SBUF_H__
#define __SBUF_H__

#include <stdio.h>
#include <stdlib.h>
#include <pthread.h>
#include <semaphore.h>

/* $begin sbuft */
typedef struct {
  int *buf;           // Buffer Array (Product/item bar)
  int *id;            // id of thread (id of Producer and customer)
  int n;              // Maximum Product/item in the slot
  int front;          // buf[(front+1)%n] is first item 
  int rear;           // buf[rear%n] is last item
  int product;        // shared product number... prevent from producer producing the same product number 
  pthread_cond_t consumer_cond;   // Condition Varible (Queue for consumer Thread)
  pthread_cond_t producer_cond;   // Condition Varible (Queue for producer Thread) 
  pthread_mutex_t mutex;          // Mutal Exclusion for let only 1 Thread working in the same time
} sbuf_t;
/* $end sbuft */

void sbuf_init(sbuf_t *sp, int n);
void sbuf_deinit(sbuf_t *sp);
void sbuf_insert(sbuf_t *sp, char *msg);
int sbuf_remove(sbuf_t *sp, char *msg);

#endif /* __SBUF_H__ */
