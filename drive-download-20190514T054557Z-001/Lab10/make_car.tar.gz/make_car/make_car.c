#include <stdio.h>
#include <pthread.h>
#include <unistd.h>
#include "common_threads.h"

#define TRUE 1
#define FALSE 0

// Status of Component of car production
int chasisReady = FALSE;
int tyreReady = FALSE;
int seatReady = FALSE;
int engineReady = FALSE;
int roofReady = FALSE; 

// Going to Make a new Car = TRUE
// Making car is on process = FALSE
int newCar = TRUE;

// Count How many car have been made
int carCount = 0;

// Monitor Condition Variable and Mutaul Exclusion
pthread_mutex_t lock;
pthread_cond_t initialChasis;     // (1) Control Chasis process 
pthread_cond_t readyForSetting;   // (2) Control Tyre, Seat and Engine process (Same Tier)
pthread_cond_t readyForRoof;      // (3) Control Roof process
pthread_cond_t readyForColor;     // (4) Control Color(painting) process

/* Chasis Process */
void putChasis()
{
  // Start making new Car!!!
  newCar = FALSE;
  carCount++;
  // put the chasis on 
  chasisReady = TRUE;
  printf("Car #%d\n", carCount);
  printf("B puts chassis on the conveyor\n");
}

/* Tyre Process */
void setTyre()
{
  // tyres are set
  tyreReady = TRUE;
  printf("A puts tires\n");
}

/* Seat Process */
void setSeat()
{
  // Seats are set
  seatReady = TRUE; 
  printf("C attaches seats\n");
}

/* Engine Process */
void setEngine()
{
  // Engine is set
  engineReady = TRUE;
  printf("D places engine\n");
}

/* Roof Process */
void setRoof()
{
  // Cover top by Roof
  roofReady = TRUE;

  printf("D assembles top cover\n");
}

/* Color Process */
void painting(){
  // Paint the Car and get a ready new car
  newCar = TRUE;
  // Reset all work
  chasisReady = FALSE;
  tyreReady = FALSE;
  seatReady = FALSE;
  engineReady = FALSE;
  roofReady = FALSE;
  printf("A paints\n\n");
}

/* B = Chasis worker */
void *B(void *arg)
{
  pthread_mutex_lock(&lock);
  while (1)
  {
    // Chasis Working
    while (chasisReady || !newCar)
    {
      pthread_cond_wait(&initialChasis, &lock);
    }
    putChasis();        // chasisReady = TRUE;
    sleep(1);
    pthread_cond_broadcast(&readyForSetting); // Report to (2) that Chasis is READY
  }
}

/* A = Tires Worker & Color Worker */
void *A(void *arg)
{
  pthread_mutex_lock(&lock);
  while (1)
  {
    // Tyre Working
    while (tyreReady || !chasisReady)
    {
      pthread_cond_wait(&readyForSetting, &lock);
    }
    setTyre();        // tyreReady = TRUE;
    sleep(1);
    pthread_cond_signal(&readyForRoof);     // Report to (3) that Tires are READY

    // Color Working
    while (!roofReady)
    {
      pthread_cond_wait(&readyForColor, &lock);
    }
    painting();       // The car is constructed completely... newCar = TRUE;
    pthread_cond_signal(&initialChasis);  // Report to (1) for starting a new cycle

  }
}

/* C = Seat Worker */
void *C(void *arg)
{
  pthread_mutex_lock(&lock);
  while (1)
  {
    // Seat Working
    while (seatReady || !chasisReady)
    {
      pthread_cond_wait(&readyForSetting, &lock);
    }
    setSeat();      // seatReady = TRUE;
    sleep(1);
    pthread_cond_signal(&readyForRoof); // Report to (3) that Seats are READY
  }
}

/* D = Engine Worker & Roof Worker */
void *D(void *arg)
{
  pthread_mutex_lock(&lock);
  while (1)
  {
    // Engine Working
    while (engineReady || !chasisReady)
    {
      pthread_cond_wait(&readyForSetting, &lock);
    }
    setEngine();    // engineReady = TRUE;
    sleep(1);
    
    // Roof Working
    while (!tyreReady || !seatReady)
    {
      pthread_cond_wait(&readyForRoof, &lock);
    }
    setRoof();      // roofReady = TRUE;
    sleep(1);
    pthread_cond_signal(&readyForColor);  // Report to (4) that Roof is READY

  }
}

int main(int argc, char *argv[])
{
  // Initial mutex & cv
  pthread_mutex_init(&lock, 0);
  pthread_cond_init(&initialChasis, 0);
  pthread_cond_init(&readyForSetting, 0);
  pthread_cond_init(&readyForRoof, 0);
  pthread_cond_init(&readyForColor, 0);

  pthread_t thread1, thread2, thread3, thread4;

  pthread_create(&thread1, NULL, A, NULL);
  pthread_create(&thread2, NULL, B, NULL);
  pthread_create(&thread3, NULL, C, NULL);
  pthread_create(&thread4, NULL, D, NULL);
  while (1)
  {
    sleep(1000);
  }
  return 0;
}
