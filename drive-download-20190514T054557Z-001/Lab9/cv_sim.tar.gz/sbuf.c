/* $begin sbufc */
#include <stdio.h>
#include <stdlib.h>
#include <pthread.h>
#include <semaphore.h>

#include "common_threads.h"
#include "sbuf.h"

// Create an empty, bounded, shared FIFO buffer with n slots
/* $begin sbuf_init */
void sbuf_init(sbuf_t *sp, int n)
{
  void *p;
  assert((p = calloc(n, sizeof(int))) != NULL);
  sp->buf = p;
  assert((p = calloc(n, sizeof(char))) != NULL);
  sp->id = p;
  sp->n = n;                       // Buffer holds max of n items 
  sp->front = sp->rear = 0;        // Empty buffer iff front == rear 
  sp->product = 1;                 // Shared Product/item number... start at number 1
  
  // initital Condition Variable and Mutex
  pthread_cond_init(&sp->consumer_cond, NULL);
  pthread_cond_init(&sp->producer_cond, NULL);
  pthread_mutex_init(&sp->mutex, NULL);
}
/* $end sbuf_init */


// Clear the shared FIFO buffer
/* $begin sbuf_deinit */
void sbuf_deinit(sbuf_t *sp)
{
  free(sp->buf);
}
/* $end sbuf_deinit */


// Producer produce i product/item then put into the shared FIFO buffer
/* $begin sbuf_insert */
void sbuf_insert(sbuf_t *sp, char *msg)
{
  int index;

  Pthread_mutex_lock(&sp->mutex);                       // Mutex for let only 1 thread working from here

  while (sp->rear - sp->front == sp->n){                // Check if shared buffer is FULL 
    Pthread_cond_wait(&sp->producer_cond, &sp->mutex);  // Let Producer wait until shared buffer has some space
  }                                                     // And Grant Mutex to another thread

  index = (++sp->rear)%(sp->n);
  sp->buf[index] = sp->product;   /* Insert the item */
  sp->id[index] = msg[0];
  printf("I am a PRODUCER # %c inserting item %d from PRODUCER # %c\n", sp->id[index], sp->product, sp->id[index]);
  printf("Number of items in queue now is %d\n", sp->rear - sp->front);

  sleep(2);                                             // Delay function - to watch output easily

  /* Two line below is the two ways to signal waiting thread(customer) */
  // Pthread_cond_signal(&sp->consumer_cond);           // Choose this line for Queue-based Priority 
  pthread_cond_broadcast(&sp->consumer_cond);           // Choose this line for Free to access (No Priority)

  Pthread_mutex_unlock(&sp->mutex);                     // Mutex unlock... Grant Mutex to another thread
}
/* $end sbuf_insert */


// Consumer come and get i product/item from shared FIFO buffer
/* $begin sbuf_remove */
int sbuf_remove(sbuf_t *sp, char *msg)
{
  int item, index;

  Pthread_mutex_lock(&sp->mutex);                       // Mutex for let only 1 thread working from here

  while (sp->rear == sp->front){                        // Check if shared buffer is EMPTY
    Pthread_cond_wait(&sp->consumer_cond, &sp->mutex);  // Let consumer wait until shard buffer has some product/item
  }                                                     // And Grant Mutex to another thread

  index = (++sp->front)%(sp->n);
  item = sp->buf[index];  /* Remove the item */
  printf("I am a consumer # %c consuming item %d from producer # %c\n", msg[0], item, sp->id[index]);
  printf("Number of items in queue now is %d\n", sp->rear - sp->front);

  sleep(2);                                             // Delay function - to watch output easily

  /* Two line below is the two ways to signal waiting thread(producer) */
  // Pthread_cond_signal(&sp->producer_cond);           // Choose this line for Queue-based Priority 
  pthread_cond_broadcast(&sp->producer_cond);           // Choose this line for Free to access (No Priority)
  
  Pthread_mutex_unlock(&sp->mutex);                     // Mutex unlock... Grant Mutex to another thread
  
  return item;
}
/* $end sbuf_remove */
