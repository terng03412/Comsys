ตอบคำถามที่ให้ตอบในห้อง

• เมื่อ simulate ทํางานเสร็จสิ้นแล้ว balance ที่เหลือในแต่ละ account มีค่าเท่าใด
80000

• ถ้าเราเปลี่ยนค่า INIT_BALANCE ที่ account.h เป็นค่า 0 เมื่อ simulate ทํางานเสร็จสิ้นแล้ว balance ที่
เหลือในแต่ละ account มีค่าเท่าใด
40000

• ถ้าเราเปลี่ยนค่า INIT_BALANCE ที่ account.h เป็นค่า 0 แล้วสลับบรรทัด 55 lender((void *)i); กับ
บรรทัดที่ 56 borrower((void *)i); เมื่อ simulate ทํางานเสร็จสิ้นแล้ว balance ที่เหลือในแต่ละ
account มีค่าเท่าใด
80000
